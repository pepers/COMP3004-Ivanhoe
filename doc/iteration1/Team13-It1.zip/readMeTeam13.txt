  _____                _                
 |_   _|              | |               
   | |_   ____ _ _ __ | |__   ___   ___ 
   | \ \ / / _` | '_ \| '_ \ / _ \ / _ \
  _| |\ V / (_| | | | | | | | (_) |  __/
 |_____\_/ \__,_|_| |_|_| |_|\___/ \___|
 |__   __|                /_ |___ \     
    | | ___  __ _ _ __ ___ | | __) |    
    | |/ _ \/ _` | '_ ` _ \| ||__ <     
    | |  __/ (_| | | | | | | |___) |    
    |_|\___|\__,_|_| |_| |_|_|____/     
Team13's README


FILES
    /doc/              (documentation folder)
        readMeTeam13.txt   (this file)
        TEAM13Mar07.pdf    (weekly progress report)
        correctionGrid.doc (iteration 1 correction grid)
        Client.jar         (Client executable from command line)
        Server.jar         (Server executable from command line) 
    /src/              (java source folder)
    /log/              (log4j logging folder)


RUNNING
    - open a command prompt/terminal
    - navigate to Client.jar and Server.jar files
    - run the Server
        - 'java -jar Server.jar'
    - run the Client
        - 'java -jar Client.jar'
    
                                        
